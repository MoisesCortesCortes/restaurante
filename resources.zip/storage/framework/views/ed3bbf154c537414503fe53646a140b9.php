

<?php $__env->startSection('content'); ?>
<h1>Camarero</h1>
<div class="row">
    <div class="container w-25 border p-4 m-1 bg-primary bg-opacity-25">
        <form method="post" action="<?php echo e(route('camarero')); ?>">
            <?php echo csrf_field(); ?>
            <h2>Nueva Comanda</h2>
            <?php $__errorArgs = ['mesa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['plato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="mb-3">
                <label for="mesa" class="form-label">Mesa:</label>
                <select class="form-select" aria-label="Default select example" name="mesa">
                    <option selected>Selecciona mesa</option>
                    <option value="1">Mesa 1</option>
                    <option value="2">Mesa 2</option>
                    <option value="3">Mesa 3</option>
                </select>
            </div>
            <div id="platos" class="mb-3">
                <label for="cantidad" class="form-label">Cantidad</label>
                <label for="plato" class="form-label">plato</label>

                <div id="plato0" class="row">
                    <div class="col-md-3">
                        <select class="form-select" aria-label="Default select example" name="cantidad[0]">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                        </select>
                    </div>
                    <div class="col">
                        <select class="form-select" aria-label="Default select example" name="plato[0]">

                            <?php $__currentLoopData = $platos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($plato->id); ?>"><?php echo e($plato->plato); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div id="add" class="col-md-2">
                        <input type="button" onclick="addPlato()" class="rounded-circle" value="+">



                    </div>

                </div>


            </div>

            <button type="submit" class="btn btn-primary">Crear comanda</button>
        </form>
    </div>

    <?php for($i=0;$i<count($pedidos);$i++): ?> 
    <div class="col container w-25 border p-4 m-1 bg-secondary bg-opacity-25">
        <h1>Pedido:<?php echo e($pedidos[$i]->id); ?></h1>
        <h2>Mesa <?php echo e($pedidos[$i]->mesa); ?></h2>
        <?php for($j=0;$j<count($comandas[$i]);$j++): ?> 
            <div class="col container border p-4 m-1 bg-success bg-opacity-25">
            <?php if($comandas[$i][$j]->servido): ?>
            <h6 class="alert alert-success">Comanda servida</h6>
            <?php endif; ?>
            <h3>Comanda: <?php echo e($comandas[$i][$j]->id); ?></h3>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $lineas[$i][$j]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><?php echo e($linea->cantidad); ?> x <?php echo e($linea->plato); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </ul>
            <?php if($comandas[$i][$j]->preparado and !$comandas[$i][$j]->servido): ?>
            <form method="post" action="<?php echo e(route('camarero-servido',['id'=>$comandas[$i][$j]->id])); ?>">

                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-primary">Marcar servido</button>
            </form>
            <?php endif; ?>
</div>
<?php endfor; ?>
<?php if($todoServido[$i]): ?>
<form method="post" action="<?php echo e(route('camarero-pagado',['id'=>$pedidos[$i]->id])); ?>">

<?php echo csrf_field(); ?>

<button type="submit" class="btn btn-primary">Marcar pagado</button>
</form>
<?php endif; ?>
</div>
<?php endfor; ?>




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moy_b\Documents\restaurante\resources\views/app/camarero.blade.php ENDPATH**/ ?>