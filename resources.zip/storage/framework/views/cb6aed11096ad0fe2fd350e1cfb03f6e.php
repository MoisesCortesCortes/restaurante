

<?php $__env->startSection('content'); ?>
<h1>Cocina</h1>
<div class="row">
    <?php for($i=0;$i<count($pedidos);$i++): ?> <?php if(count($comandas[$i])): ?> <div class="col container w-25 border p-4 m-1 bg-secondary bg-opacity-25">
        <h1>Pedido:<?php echo e($pedidos[$i]->id); ?></h1>
        <h2>Mesa <?php echo e($pedidos[$i]->mesa); ?></h2>
        <?php for($j=0;$j<count($comandas[$i]);$j++): ?> <div class="col container border p-4 m-1 bg-success bg-opacity-25">

            <?php if($comandas[$i][$j]->preparado): ?>
            <h6 class="alert alert-success">Listo para servir</h6>
            <?php endif; ?>

            <h3>Comanda: <?php echo e($comandas[$i][$j]->id); ?></h3>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $lineas[$i][$j]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><?php echo e($linea->cantidad); ?> x <?php echo e($linea->plato); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </ul>
            <?php if(!$comandas[$i][$j]->preparado): ?>
            <form method="post" action="<?php echo e(route('cocina-listo',['id'=>$comandas[$i][$j]->id])); ?>">

                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-primary">Listo para servir</button>
            </form>
            <?php endif; ?>

</div>
<?php endfor; ?>
</div>
<?php endif; ?>
<?php endfor; ?>




</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moy_b\Documents\restaurante\resources\views/app/cocina.blade.php ENDPATH**/ ?>