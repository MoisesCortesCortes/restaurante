

<?php $__env->startSection('content'); ?>
    
    <div class="container w-25 border p-4">
    <h1>Administración</h1>
    <div class="row mx-auto">
    <form  method="POST" action="<?php echo e(route('admin')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3 col">
        <?php $__errorArgs = ['plato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if(session('success')): ?>
                <h6 class="alert alert-success"><?php echo e(session('success')); ?></h6>
        <?php endif; ?>
            <label for="title" class="form-label">Plato:</label>
            <input type="text" class="form-control mb-2" name="plato" id="plato" placeholder="Arroz con pollo">

            
            <input type="submit" value="Crear plato" class="btn btn-primary my-2" />
        </div>
    </form>

    <div >
        <?php $__currentLoopData = $platos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="row py-1">
                <div class="col-md-9 d-flex align-items-center">
                    <a href="<?php echo e(route('plato-edit', ['id' => $plato->id])); ?>"><?php echo e($plato->plato); ?></a>
                </div>

                <div class="col-md-3 d-flex justify-content-end">
                    <form action="<?php echo e(route('plato-destroy', [$plato->id])); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moy_b\Documents\restaurante\resources\views/app/admin.blade.php ENDPATH**/ ?>